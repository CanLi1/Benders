To execute these files place them first in
MyDocuments/gamsdir/project
To run read file LagrangeanMultisite from GAMSID
